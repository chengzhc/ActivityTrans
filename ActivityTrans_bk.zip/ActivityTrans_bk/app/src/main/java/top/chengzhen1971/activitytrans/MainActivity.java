package top.chengzhen1971.activitytrans;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btn_to_page2,btn_to_page_send_data,btn_to_page_get_data;
    EditText et_input;
    TextView tv_info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_to_page2 = findViewById(R.id.btn_to_page2);
        btn_to_page2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToPage2();
            }
        });

        btn_to_page_send_data = findViewById(R.id.btn_to_page_send_data);
        btn_to_page_send_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToPage2SendData();
            }
        });

        btn_to_page_get_data = findViewById(R.id.btn_to_page2_get_data);
        btn_to_page_get_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToPage2GetData();
            }
        });

        et_input = findViewById(R.id.et_input);

        tv_info = findViewById(R.id.tv_info);

    }

    /**
     * 跳转第二页不传值
     */
    void goToPage2(){
        Intent intent = new Intent(this,Page2Activity.class);
        startActivity(intent);
    }

    /**
     * 跳转第二页并传值
     */
    void goToPage2SendData(){
        Intent intent = new Intent(this,Page2Activity.class);
        intent.putExtra("data1","这是跳转传值的测试");
        intent.putExtra("input",et_input.getText().toString());
        startActivity(intent);
    }

    /**
     * 跳转第二页并传值,且接收返回值
     */
    void goToPage2GetData(){
        Intent intent = new Intent(this,Page2Activity.class);
        intent.putExtra("data1","这是传值并接受返回的测试");
        intent.putExtra("input",et_input.getText().toString());
        //123是请求码，为了让下一页知道是哪一页跳过来的
        startActivityForResult(intent,123);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if((requestCode==123)&&(resultCode==10)){
            String resultData =  data.getStringExtra("back_msg");
            tv_info.setText("收到 Page2Activity 返回的数据："+resultData);
        }
    }
}
