package top.chengzhen1971.activitytrans;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Page2Activity extends AppCompatActivity {

    Button btn_back;
    TextView tv_info;
    EditText et_input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);

        initData();
        initView();
        showReveiceData();
    }

    void initData(){

    }

    void initView(){
        btn_back = findViewById(R.id.btn_back);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backToMainPage();
            }
        });

        tv_info = findViewById(R.id.tv_info);
        et_input = findViewById(R.id.et_input2);
    }

    void showReveiceData(){
        Intent getIntent = getIntent();
        String data1 = getIntent.getStringExtra("data1");
        String input = getIntent.getStringExtra("input");
        tv_info.setText("获取参数data1："+data1+"\n获取输入："+input);
    }

    void backToMainPage(){
        Intent intent = new Intent();
        intent.putExtra("back_msg",et_input.getText().toString());
        //10是结果码，让返回的页面知道是哪个页面返回的
        setResult(10,intent);
        finish();
    }
}
